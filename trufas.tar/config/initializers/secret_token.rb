# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Trufas::Application.config.secret_token = 'c58af8bbad04c9d966ce8d798404bbb14ae2c580621c0804e9a959e3b5be1042f135b49eb70a01df2df2f2f1639932a0f021f93f2bc53be4a78dc00591cb35c5'
