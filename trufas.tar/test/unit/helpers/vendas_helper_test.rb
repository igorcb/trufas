require 'test_helper'

class VendasHelperTest < ActionView::TestCase
end
