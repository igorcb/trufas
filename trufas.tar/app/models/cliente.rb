class Cliente < ActiveRecord::Base
  has_many :vendas
end
