class Produto < ActiveRecord::Base
  has_many :items
end
